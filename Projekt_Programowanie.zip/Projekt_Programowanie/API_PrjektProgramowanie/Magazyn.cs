﻿namespace API_PrjektProgramowanie
{
    public class Magazyn
    {
    }
}
