﻿namespace API_PrjektProgramowanie
{
    public class Zamowienie
    {
    }
}
