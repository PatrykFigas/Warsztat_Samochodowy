﻿namespace API_PrjektProgramowanie
{
    public class ZlecenieSerwisowe
    {
    }
}
